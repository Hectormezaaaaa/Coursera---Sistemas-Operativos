
//Hector Meza


const authenticationHandler = require('passport');
const localAuthStrategy = require('passport-local').Strategy;
const UserProfile = require('./models/User');

// Local authentication strategy for email and password login
authenticationHandler.use(new localAuthStrategy({
  usernameField: 'emailAddress',
  passwordField: 'userPassword'
}, async (emailAddress, userPassword, next) => {
  try {
    const foundUser = await UserProfile.findOne({ email: emailAddress });
    if (!foundUser) return next(null, false, { message: 'Email not registered' });
    if (!foundUser.isVerified) return next(null, false, { message: 'Account not verified' });
    const passwordMatch = await foundUser.comparePassword(userPassword);
    if (!passwordMatch) return next(null, false, { message: 'Incorrect password' });
    return next(null, foundUser);
  } catch (err) {
    return next(err);
  }
}));

// Serialize user
authenticationHandler.serializeUser((userProfile, next) => {
  next(null, userProfile.id);
});

// Deserialize user
authenticationHandler.deserializeUser(async (userId, next) => {
  try {
    const foundUser = await UserProfile.findById(userId);
    next(null, foundUser);
  } catch (err) {
    next(err);
  }
});

module.exports = authenticationHandler;