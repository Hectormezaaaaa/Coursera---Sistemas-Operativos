

//Hector Meza

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const UserProfileSchema = new mongoose.Schema({
  userEmail: { 
    type: String, 
    required: true, 
    unique: true, 
    trim: true,
    lowercase: true,
  },
  userPassword: { 
    type: String, 
    required: true,
    minlength: 8
  },
  passwordResetToken: {
    type: String
  },
  passwordResetTokenExpires: {
    type: Date
  },
  isVerified: { 
    type: Boolean, 
    default: false 
  }
});

// Encripta la contraseña antes de guardarla.
UserProfileSchema.pre('save', async function(next) {
  if (!this.isModified('userPassword')) return next();
  const salt = await bcrypt.genSalt(10);
  this.userPassword = await bcrypt.hash(this.userPassword, salt);
  next();
});

// Método para verificar la contraseña.
UserProfileSchema.methods.compareUserPassword = function(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.userPassword);
};

module.exports = mongoose.model('UserProfile', UserProfileSchema);