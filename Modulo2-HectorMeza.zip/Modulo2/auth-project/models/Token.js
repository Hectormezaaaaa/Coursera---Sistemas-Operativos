//Hector Meza


const mongoose = require('mongoose');

const authSchema = new mongoose.Schema({
  idUser: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  },
  vToken: { 
    type: String, 
    required: true 
  },
  createdAt: { 
    type: Date, 
    default: Date.now, 
    expires: '1h' 
  }
});

const authModel = mongoose.model('AuthToken', authSchema);

module.exports = authModel;