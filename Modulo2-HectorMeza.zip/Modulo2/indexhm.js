//Hector Meza

require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const passport = require('./passport');
const bodyParser = require('body-parser');
const User = require('./models/User');
const Token = require('./models/Token');
const jwt = require('jsonwebtoken');
const nodemailer = require('nodemailer');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Sesiones y passport
app.use(session({ secret: 'secretSessionKey', resave: false, saveUninitialized: false }));
app.use(passport.initialize());
app.use(passport.session());

// Conectar a la base de datos
mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

// Configurar servicio de correo
const mailer = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Middleware para proteger rutas web
function protectRoute(req, res, next) {
  if (req.isAuthenticated()) return next();
  res.redirect('/login');
}

// Middleware para proteger rutas API con JWT
function protectApi(req, res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader) {
    const token = authHeader.split(' ')[1];
    jwt.verify(token, process.env.JWT_SECRET, (err, payload) => {
      if (err) return res.status(403).json({ message: 'Token no válido' });
      req.user = payload;
      next();
    });
  } else {
    res.status(401).json({ message: 'Acceso denegado, falta token' });
  }
}

// Rutas de la aplicación

// Vista de login
app.get('/login', (req, res) => {
  res.send(`<form action="/login" method="post">
              Email: <input name="email" type="email" /><br/>
              Password: <input name="password" type="password" /><br/>
              <button type="submit">Login</button>
            </form>`);
});

// Autenticación con Passport
app.post('/login', passport.authenticate('local', {
  successRedirect: '/dashboard',
  failureRedirect: '/login?error=true'
}));

// Vista de panel de control protegida
app.get('/dashboard', protectRoute, (req, res) => {
  res.send(`Bienvenido ${req.user.email} <br/><a href="/logout">Cerrar sesión</a>`);
});

// Cierre de sesión
app.get('/logout', (req, res) => {
  req.logout(() => {
    res.redirect('/login');
  });
});

// Registro de usuario
app.post('/register', async (req, res) => {
  const { email, password } = req.body;
  try {
    let existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: 'Email ya registrado' });

    let newUser = new User({ email, password, verificado: false });
    await newUser.save();

    // Generar token de verificación
    const tokenStr = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET, { expiresIn: '1d' });
    const verificationToken = new Token({ user: newUser._id, token: tokenStr });
    await verificationToken.save();

    // Enviar email de verificación
    const verifyUrl = `${process.env.BASE_URL}/verify/${tokenStr}`;
    await mailer.sendMail({
      to: newUser.email,
      subject: 'Verifica tu cuenta',
      html: `Bienvenido! Por favor verifica tu cuenta haciendo click <a href="${verifyUrl}">aquí</a>`
    });

    res.json({ message: 'Usuario registrado, revisa tu email para verificar tu cuenta.' });
  } catch (error) {
    res.status(500).json({ message: 'Error en el servidor' });
  }
});

// Verificar cuenta
app.get('/verify/:token', async (req, res) => {
  try {
    const { token } = req.params;
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const doc = await Token.findOne({ token });
    if (!doc) return res.status(400).send('Token inválido o expirado');

    const user = await User.findById(payload.userId);
    if (!user) return res.status(400).send('Usuario no encontrado');

    user.verificado = true;
    await user.save();
    await Token.deleteOne({ token });

    res.send('Cuenta verificada correctamente, ya puedes iniciar sesión.');
  } catch (error) {
    res.status(400).send('Token inválido o expirado');
  }
});

// Recuperar contraseña
app.post('/forgot-password', async (req, res) => {
  const { email } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ message: 'Email no encontrado' });

    const tokenStr = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    user.passwordResetToken = tokenStr;
    user.passwordResetTokenExpires = Date.now() + 3600000;
    await user.save();

    const resetUrl = `${process.env.BASE_URL}/reset-password/${tokenStr}`;
    await mailer.sendMail({
      to: user.email,
      subject: 'Reset de contraseña',
      html: `Click para resetear tu contraseña: <a href="${resetUrl}">Resetear</a>`
    });

    res.json({ message: 'Email de recuperación enviado' });
  } catch {
    res.status(500).json({ message: 'Error en el servidor' });
  }
});

// Formulario de cambio de contraseña
app.get('/reset-password/:token', async (req, res) => {
  const { token } = req.params;
  try {
    const user = await User.findOne({ passwordResetToken: token, passwordResetTokenExpires: { $gt: Date.now() } });
    if (!user) return res.status(400).send('Token inválido o expirado');

    res.send(`<form action="/reset-password/${token}" method="post">
                Nueva contraseña: <input name="password" type="password" />
                <button type="submit">Cambiar</button>
              </form>`);
  } catch {
    res.status(500).send('Error en el servidor');
  }
});

// Cambiar contraseña
app.post('/reset-password/:token', async (req, res) => {
  const { token } = req.params;
  const { password } = req.body;
  try {
    const user = await User.findOne({ passwordResetToken: token, passwordResetTokenExpires: { $gt: Date.now() } });
    if (!user) return res.status(400).send('Token inválido o expirado');

    user.password = password;
    user.passwordResetToken = undefined;
    user.passwordResetTokenExpires = undefined;
    await user.save();

    res.send('Contraseña cambiada con éxito.');
  } catch {
    res.status(500).send('Error en el servidor');
  }
});

// Ruta API protegida con JWT (ejemplo: bicicletas)
app.get('/api/bicicletas', protectApi, (req, res) => {
  res.json([{ id: 1, modelo: 'Mountain Bike' }, { id: 2, modelo: 'BMX' }]);
});

// Login API que devuelve token JWT
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ message: 'Email no registrado' });
    if (!user.verificado) return res.status(401).json({ message: 'Cuenta no verificada' });

    const match = await user.comparePassword(password);
    if (!match) return res.status(401).json({ message: 'Contraseña incorrecta' });

    const token = jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '24h' });
    res.json({ token });
  } catch {
    res.status(500).json({ message: 'Error en el servidor' });
  }
});

app.listen(process.env.PORT, () => {
  console.log(`Servidor corriendo en puerto ${process.env.PORT}`);
});