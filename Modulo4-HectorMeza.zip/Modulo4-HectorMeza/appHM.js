require('newrelic');
require('dotenv').config();

const framework = require('express');
const sessionHandler = require('express-session');
const authSystem = require('./config/passport');
const dataStore = require('./db');
const mailAgent = require('./mailer');
const appUser = require('./models/User');

const app = framework();

app.use(framework.json());
app.use(framework.urlencoded({ extended: true }));

app.use(sessionHandler({
  secret: 'clave_secreta_de_sesion',
  resave: false,
  saveUninitialized: false
}));

app.use(authSystem.initialize());
app.use(authSystem.session());

// Puntos de entrada para autenticación con Google
app.get('/login/google',
  authSystem.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/login/google/callback',
  authSystem.authenticate('google', { failureRedirect: '/acceso' }),
  (req, res) => {
    res.redirect('/panel');
  });

// Puntos de entrada para autenticación con Facebook
app.get('/login/facebook',
  authSystem.authenticate('facebook', { scope: ['email'] }));

app.get('/login/facebook/callback',
  authSystem.authenticate('facebook', { failureRedirect: '/acceso' }),
  (req, res) => {
    res.redirect('/panel');
  });

// Ruta de usuario autenticado
app.get('/panel', (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/acceso');
  res.send(`Hola ${req.user.name}, bienvenido a tu panel de control.`);
});

app.get('/acceso', (req, res) => {
  res.send('<a href="/login/google">Entrar con Google</a><br><a href="/login/facebook">Entrar con Facebook</a>');
});

// Ejemplo de registro
app.post('/registro', async (req, res) => {
  const { email, name } = req.body;
  let user = new appUser({ email, name, verified: false });
  await user.save();

  const mailOptions = {
    from: process.env.CORREO_DE_ORIGEN || 'no-reply@mi-app.com',
    to: email,
    subject: 'Verifica tu cuenta de usuario',
    html: `<p>Hola ${name}, por favor confirma tu cuenta en <a href="${process.env.URL_BASE_APP}/confirmar">este enlace</a></p>`
  };
  try {
    await mailAgent.sendMail(mailOptions);
    res.send('Usuario registrado y correo de verificación enviado');
  } catch (e) {
    res.status(500).send('Hubo un error al enviar el correo');
  }
});

const PUERTO = process.env.PORT || 3000;
app.listen(PUERTO, () => {
  console.log(`Servidor iniciado en el puerto ${PUERTO}`);
});