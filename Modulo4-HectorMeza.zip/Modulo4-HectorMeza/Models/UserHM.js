// models/Account.js
const db = require('mongoose');

const AccountSchema = new db.Schema({
  googleReference: String,
  facebookReference: String,
  mainEmail: { type: String, required: true },
  userName: String,
  status: { type: Boolean, default: false }
});

AccountSchema.statics.fetchOrCreateGoogle = async function(userData) {
  let account = await this.findOne({ googleReference: userData.id });
  if (!account) {
    account = new this({
      googleReference: userData.id,
      mainEmail: userData.emails[0].value,
      userName: userData.displayName,
      status: true
    });
    await account.save();
  }
  return account;
};

AccountSchema.statics.fetchOrCreateFacebook = async function(userData) {
  let account = await this.findOne({ facebookReference: userData.id });
  if (!account) {
    account = new this({
      facebookReference: userData.id,
      mainEmail: userData.emails[0].value,
      userName: userData.displayName,
      status: true
    });
    await account.save();
  }
  return account;
};

module.exports = db.model('Account', AccountSchema);