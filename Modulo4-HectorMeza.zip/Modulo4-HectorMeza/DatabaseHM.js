// connection.js
const database = require('mongoose');
require('dotenv').config();

const connectionString = process.env.NODE_ENV === 'production' ? process.env.DB_URI_PROD : process.env.DB_URI_DEV;

database.connect(connectionString, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log(`Conexión a la base de datos exitosa en el entorno de ${process.env.NODE_ENV}`))
  .catch(err => console.error(err));

module.exports = database;