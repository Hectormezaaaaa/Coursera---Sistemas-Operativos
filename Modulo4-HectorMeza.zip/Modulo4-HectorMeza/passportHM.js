const credenciales = require('passport');
const GAuthStrategy = require('passport-google-oauth20').Strategy;
const FBAuthStrategy = require('passport-facebook').Strategy;
const AppUser = require('./models/User');

credenciales.serializeUser((usuario, done) => done(null, usuario.id));
credenciales.deserializeUser(async (id, done) => {
  try {
    const usuario = await AppUser.findById(id);
    done(null, usuario);
  } catch (err) {
    done(err);
  }
});

// Estrategia de acceso con Google
credenciales.use(new GAuthStrategy({
  clientID: process.env.GOOGLE_APP_KEY,
  clientSecret: process.env.GOOGLE_APP_SECRET_KEY,
  callbackURL: `${process.env.APP_ORIGIN}/auth/google/callback`
}, async (tokenAcceso, tokenRefresco, perfil, done) => {
  try {
    const usuario = await AppUser.findOneOrCreateByGoogle(perfil);
    done(null, usuario);
  } catch (err) {
    done(err);
  }
}));

// Estrategia de acceso con Facebook
credenciales.use(new FBAuthStrategy({
  clientID: process.env.FACEBOOK_APP_KEY,
  clientSecret: process.env.FACEBOOK_APP_SECRET_KEY,
  callbackURL: `${process.env.APP_ORIGIN}/auth/facebook/callback`,
  profileFields: ['id', 'emails', 'name', 'displayName']
}, async (tokenAcceso, tokenRefresco, perfil, done) => {
  try {
    const usuario = await AppUser.findOneOrCreateByFacebook(perfil);
    done(null, usuario);
  } catch (err) {
    done(err);
  }
}));

module.exports = credenciales;