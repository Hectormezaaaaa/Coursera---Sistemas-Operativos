require('newrelic'); // Se mantiene en el inicio

const serverApp = require('express');
const sessionStore = require('express-session');
const loginManager = require('./passport');
const databaseConnection = require('./db');
const emailSender = require('./mailer');
const userModel = require('./models/User');

const app = serverApp();
app.use(serverApp.json());
app.use(serverApp.urlencoded({ extended: true }));

app.use(sessionStore({
  secret: 'app_secret_key',
  resave: false,
  saveUninitialized: false
}));

app.use(loginManager.initialize());
app.use(loginManager.session());

// Puntos de entrada para Google
app.get('/oauth/google',
  loginManager.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/oauth/google/callback',
  loginManager.authenticate('google', { failureRedirect: '/acceso' }),
  (req, res) => {
    res.redirect('/home-page');
  });

// Puntos de entrada para Facebook
app.get('/oauth/facebook',
  loginManager.authenticate('facebook', { scope: ['email'] }));

app.get('/oauth/facebook/callback',
  loginManager.authenticate('facebook', { failureRedirect: '/acceso' }),
  (req, res) => {
    res.redirect('/home-page');
  });

// Página principal del usuario
app.get('/home-page', (req, res) => {
  if (!req.isAuthenticated()) return res.redirect('/acceso');
  res.send(`¡Hola, ${req.user.name}! Te damos la bienvenida.`);
});

// Ejemplo de creación de usuario con correo electrónico
app.post('/new-user', async (req, res) => {
  const { email, name } = req.body;
  let newUser = new userModel({ email, name, verified: false });
  await newUser.save();

  const mailOptions = {
    from: process.env.EMAIL_SOURCE || 'no-reply@app-web.com',
    to: email,
    subject: '¡Bienvenido! Confirma tu cuenta',
    html: `<p>Hola ${name}, por favor, haz clic <a href="${process.env.APP_ORIGIN_URL}/confirm">aquí</a> para verificar tu cuenta.</p>`
  };
  await emailSender.sendMail(mailOptions);
  res.send('Usuario registrado y correo de confirmación enviado.');
});

// Iniciar servidor
const APP_PORT = process.env.PORT || 3000;
app.listen(APP_PORT, () => console.log(`La aplicación se está ejecutando en el puerto ${APP_PORT}`));