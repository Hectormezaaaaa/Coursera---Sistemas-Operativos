const mailer = require('nodemailer');
require('dotenv').config();

let mailProvider;

if (process.env.NODE_ENV === 'production') {
  const sgService = require('nodemailer-sendgrid-transport');
  mailProvider = mailer.createTransport(sgService({
    auth: {
      api_key: process.env.SG_KEY
    }
  }));
} else {
  mailProvider = mailer.createTransport({
    host: 'smtp.ethereal.email',
    port: 587,
    auth: {
      user: process.env.ETHEREAL_USER_EMAIL,
      pass: process.env.ETHEREAL_USER_PASS
    }
  });
}

module.exports = mailProvider;