const express = require('express');
const mongoose = require('mongoose');
const Bicicleta = require('./models/bicicleta');

const app = express();

app.use(express.json());

mongoose.connect('mongodb://localhost:27017/red_bicicletas', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

mongoose.connection.once('open', () => {
  console.log('Conectado a MongoDB red_bicicletas');
});

// Rutas CRUD bicicletas

app.post('/api/bicicletas', async (req, res) => {
  try {
    const bici = new Bicicleta(req.body);
    await bici.save();
    res.status(201).json(bici);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/bicicletas', async (req, res) => {
  const bicis = await Bicicleta.find();
  res.json(bicis);
});

app.get('/api/bicicletas/:code', async (req, res) => {
  const bici = await Bicicleta.findOne({ code: req.params.code });
  if (!bici) return res.status(404).json({ error: 'Bicicleta no encontrada' });
  res.json(bici);
});

app.put('/api/bicicletas/:code', async (req, res) => {
  try {
    const bici = await Bicicleta.findOneAndUpdate({ code: req.params.code }, req.body, { new: true });
    if (!bici) return res.status(404).json({ error: 'Bicicleta no encontrada' });
    res.json(bici);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.delete('/api/bicicletas/:code', async (req, res) => {
  const result = await Bicicleta.deleteOne({ code: req.params.code });
  if (result.deletedCount === 0) return res.status(404).json({ error: 'Bicicleta no encontrada' });
  res.status(204).send();
});

module.exports = app;
