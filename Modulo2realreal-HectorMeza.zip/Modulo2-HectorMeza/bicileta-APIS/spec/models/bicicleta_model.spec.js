const mongoose = require('mongoose');
const BicycleModel = require('../../models/bicicleta');

const TEST_DB_URI = 'mongodb://localhost:27017/bicycle_tests';

beforeAll(async () => {
  await mongoose.connect(TEST_DB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
  await BicycleModel.deleteMany({});
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe('Bicycle Model Persistence', () => {
  test('Creating and saving a bicycle', async () => {
    const newBicycle = new BicycleModel({ 
      code: 10, 
      color: 'green', 
      modelo: 'mountain', 
      ubicacion: [-99.2, 19.3] 
    });
    await newBicycle.save();

    const foundBicycle = await BicycleModel.findOne({ code: 10 });
    expect(foundBicycle).not.toBeNull();
    expect(foundBicycle.color).toBe('green');
  });

  test('Updating a bicycle', async () => {
    await BicycleModel.findOneAndUpdate({ code: 10 }, { color: 'black' });
    const updatedBicycle = await BicycleModel.findOne({ code: 10 });
    expect(updatedBicycle.color).toBe('black');
  });

  test('Deleting a bicycle', async () => {
    await BicycleModel.deleteOne({ code: 10 });
    const deletedBicycle = await BicycleModel.findOne({ code: 10 });
    expect(deletedBicycle).toBeNull();
  });
});