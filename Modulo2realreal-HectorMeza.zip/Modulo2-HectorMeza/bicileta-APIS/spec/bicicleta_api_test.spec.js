const request = require('supertest');
const mongoose = require('mongoose');
const server = require('../app');
const Bike = require('../models/bicicleta');

const DB_URI = 'mongodb://localhost:27017/red_bicicletas_test';

beforeAll(async () => {
  await mongoose.connect(DB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
  await Bike.deleteMany({});
});

afterAll(async () => {
  await mongoose.connection.close();
});

describe('API Tests', () => {
  test('POST /api/bikes creates a new bike', async () => {
    const bikeData = { code: 1, color: 'red', modelo: 'urban', ubicacion: [-99.1, 19.4] };
    const res = await request(server).post('/api/bicicletas').send(bikeData);
    expect(res.statusCode).toBe(201);
    expect(res.body.code).toBe(1);
  });

  test('GET /api/bikes returns all bikes', async () => {
    const res = await request(server).get('/api/bicicletas');
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
  });

  test('GET /api/bikes/:code returns the correct bike', async () => {
    const res = await request(server).get('/api/bicicletas/1');
    expect(res.statusCode).toBe(200);
    expect(res.body.code).toBe(1);
  });

  test('PUT /api/bikes/:code updates the bike', async () => {
    const updateData = { color: 'blue' };
    const res = await request(server).put('/api/bicicletas/1').send(updateData);
    expect(res.statusCode).toBe(200);
    expect(res.body.color).toBe('blue');
  });

  test('DELETE /api/bikes/:code removes the bike', async () => {
    const res = await request(server).delete('/api/bicicletas/1');
    expect(res.statusCode).toBe(204);
  });
});