const mongoose = require('mongoose');

const bicycleSchema = new mongoose.Schema({
  bicycleCode: {
    type: Number,
    required: true,
    unique: true
  },
  bicycleColor: String,
  bicycleModel: String,
  locationCoordinates: {
    type: [Number], // [longitude, latitude]
    index: '2dsphere',
    sparse: true,
  },
});

const BicycleModel = mongoose.model('Bicycle', bicycleSchema);

module.exports = BicycleModel;