const serverApp = require('./app');
const SERVER_PORT = 4000;

serverApp.listen(SERVER_PORT, () => {
  console.log(`Server running at http://localhost:${SERVER_PORT}`);
});